THE CHRONICLES OF LIGHT AND MAGIC

CHAPTERS


IMAGES:
All images should be placed in an ./Images/<PROPER_SUBDIRECTORY> folder  

In chapter link an image using:
[IMAGE: "./Images/pathtoimage/*"]
[IMAGE: "./Images/pathtoimage/image_name.jpg"]
[IMAGE: "./Images/pathtoimage/image{{12-18}}.jpg"]


OTHER FILES:
Files of all othefr types than images should be placed in
In chapter link a file using:
[TYPE: "./Others/file_name.hmm"]
